---
name: tuoverse-scraper
description: 从 tuoverse.com（沱书·文存）批量抓取完本小说正文并生成干净 TXT。通过 CDP 复用带 cf_clearance 的 Chrome profile 绕过 Cloudflare Managed Challenge，逐页提取 #chapterText 逐字原文，清洗行内水印，按顺序拼接并加上自定义头尾水印。This skill should be used when the user asks to fetch/download/scrape a full novel from tuoverse.com (沱书), bypass its Cloudflare challenge, or assemble scraped pages into a cleaned TXT.
---

# 沱书抓取器 (tuoverse-scraper)

## Overview

从 tuoverse.com（沱书·文存）抓取整本小说的**逐字原文**，输出带自定义水印的干净 TXT。

关键事实（踩坑后确认，务必遵守）：

- 站点 URL 形如 `https://tuoverse.com/novel/<novelId>/chapter-N.html`。**N 是分页号，不是章节号**。全书按页连续，`chapter-1.html` 通常是简介/文案页，正文从 `chapter-2.html` 开始。
- 正文容器是 `main#chapterText.chapter-text`；其 `innerText` 是逐字原文。**绝不要用 `web_fetch`**（它经过 AI 处理，会改写/规范化敏感词，如把 `三年□□` 改成通顺表达），必须用 CDP 读 DOM。
- 站点对 curl / headless Chrome / 代理（allorigins、codetabs、jina、corsproxy）一律返回 Cloudflare Managed Challenge（HTTP 403，title=`Just a moment...`）。唯一可靠路径是：**CDP 连接一个已通过验证、带有效 `cf_clearance` cookie 的 Chrome profile**。
- 每页正文里会插入行内水印 `<书名>_<作者>`（如 `在艰苦岁月里当阿姐_九紫`），必须删除。
- 源站可能跳号/合并章节（例：44 章内容里含 45 章正文但没有「第45章」标题）。这属于源站原始编号，不要试图补标题。

## Workflow Decision Tree

- 用户给出 tuoverse 小说链接/novelId，要抓全书 → 走下方「完整流程」
- 只需要单页/几页校对 → 用脚本的 `--start` / `--end` 限定页码
- 已有 `tuo_pages/page-*.txt` 缓存，只要重新拼接 → 只跑 `tuo_assemble.js`
- Chrome 访问返回 Cloudflare 挑战页 → 见 `references/workflow.md` 的「Cookie 准备与续期」

## 完整流程

### 前置条件

1. Node.js（脚本仅用内置模块 + `ws`）。首次需 `npm install ws --no-save`（在某个工作目录）。
2. 一个**已通过 Cloudflare 验证**的 Chrome profile 目录（含有效 `cf_clearance` cookie）。准备方法见 `references/workflow.md`。默认脚本会尝试自动定位或要求通过 `--profile` 传入。

### 第 1 步：批量抓取分页

```bash
node scripts/tuo_cdp.js --novel 4be52039 --start 1 --end 409 \
  --profile <带cf_clearance的profile目录> --outdir <工作目录>/tuo_pages
```

- 脚本用 CDP 顺序导航 `chapter-N.html`，提取 `main#chapterText` 的逐字 `innerText`，逐行 trim、去空行后写入 `page-NNN.txt`。
- 支持断点续传：已存在且非空的文件自动跳过；失败页写入 `failures.txt`，可只重跑失败页。
- 完成后确认日志 `DONE ok=... fail=0`。若有失败页，重跑一次（脚本会跳过已成功页）。

### 第 2 步：拼接为 TXT

```bash
node scripts/tuo_assemble.js --indir <工作目录>/tuo_pages \
  --first 2 --last 409 \
  --title 在艰苦岁月里当阿姐 --author 九紫 \
  --share "更多书源分享，小程序搜：数维探索。最新资源获取方式：加入官方反馈群1041698859" \
  --out <目标>.txt --apply
```

- `--first 2` 跳过简介页，从正文第一页开始。
- 脚本自动跳过正文前的文案块（定位第一个独立成行的 `第1章`），删除 508+ 处行内水印，校验章节号连续性（源站跳号会列出但进程不中断）。
- **默认只试运行并打印统计**；确认无误后加 `--apply` 才覆盖目标文件，覆盖前自动备份为 `<目标>.bak`。

### 第 3 步：校验

拼接后核对：文件头尾水印各 1 次、站点行内水印残留 0、广告残留 0、章节标题数、从原始页随机抽段用 `final.includes(probe)` 验证逐字一致。详细清单见 `references/workflow.md`。

## 关键实现约束

- CDP 连接的是 page 的 `webSocketDebuggerUrl`，**不要传 sessionId**（直接用扁平 session）。
- 导航后轮询等待 `document.title` 匹配 `第<N>页` 且 `#chapterText` 有内容再提取；出现 `Just a moment/请稍候/Attention Required` 视为挑战页并重试。
- `cf_clearance` 绑定 IP 与 UA：必须使用原来那个 profile、同一网络、默认 UA（不要自定义 `--user-agent`）。cookie 失效就重新走 `references/workflow.md` 的续期流程。
- 所有脚本默认 **dry-run**，仅 `--apply` 才写目标文件。

## Resources

### scripts/
- `scripts/tuo_cdp.js` — CDP 批量抓取器。参数：`--novel --start --end --profile --outdir --port --chrome --selector`。
- `scripts/tuo_assemble.js` — 清洗拼接器。参数：`--indir --first --last --title --author --share --out --apply` 等。

### references/
- `references/workflow.md` — 完整工作流、Cookie 准备与续期、页面/DOM 结构、清洗与校验清单、故障排查表、实测数据。
