#!/usr/bin/env node
/**
 * 沱书 (tuoverse.com) 批量分页抓取器 —— 通过 CDP + cf_clearance 绕过 Cloudflare。
 * 仅用 Node 内置模块 + ws（npm install ws --no-save）。
 *
 * 用法:
 *   node tuo_cdp.js --novel 4be52039 --start 1 --end 409 \
 *     --profile <带cf_clearance的profile目录> --outdir <输出目录>
 *
 * 参数:
 *   --novel    小说 ID（默认 4be52039）
 *   --start    起始页（默认 1）
 *   --end      结束页（默认 409）
 *   --profile  Chrome profile 目录（必填；必须含有效 cf_clearance cookie）
 *   --outdir   页面输出目录（默认 ./tuo_pages）
 *   --port     CDP 端口（默认 9341）
 *   --chrome   chrome.exe 路径（默认自动探测）
 *   --selector 正文容器选择器（默认 #chapterText）
 *   --retry    单页最大重试次数（默认 3）
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');
let WebSocket;
try { WebSocket = require('ws'); }
catch (e) { console.error('缺少 ws 模块，请先运行: npm install ws --no-save'); process.exit(1); }

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  if (i >= 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--')) return process.argv[i + 1];
  const eq = process.argv.find(a => a.startsWith('--' + name + '='));
  return eq ? eq.slice(name.length + 3) : def;
}
const NOVEL = arg('novel', '4be52039');
const START = parseInt(arg('start', '1'), 10);
const END = parseInt(arg('end', '409'), 10);
const PROFILE = arg('profile', '');
const OUTDIR = path.resolve(arg('outdir', 'tuo_pages'));
const PORT = parseInt(arg('port', '9341'), 10);
const SELECTOR = arg('selector', '#chapterText');
const RETRY = parseInt(arg('retry', '3'), 10);
const BASE = `https://tuoverse.com/novel/${NOVEL}/chapter-`;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function findChrome(explicit) {
  if (explicit && fs.existsSync(explicit)) return explicit;
  const cands = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    '/usr/bin/google-chrome', '/usr/bin/chromium',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  ];
  return cands.find(p => fs.existsSync(p));
}
const CHROME = findChrome(arg('chrome', ''));

function getJson(url) {
  return new Promise((res, rej) => {
    http.get(url, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); }).on('error', rej);
  });
}
let seq = 0;
const pending = new Map();
function send(ws, method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++seq;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject(new Error('CDP timeout: ' + method)); } }, 30000);
  });
}
const CHALLENGE_RE = /Just a moment|请稍候|Attention Required|Enable JavaScript|Checking your browser/i;

async function extractPage(ws) {
  const expr = `(function(){
    const el=document.querySelector(${JSON.stringify(SELECTOR)});
    if(!el) return {ok:false, reason:'no container', title:document.title};
    const lines=(el.innerText||'').split(/\\n/).map(x=>x.trim()).filter(Boolean);
    return {ok:lines.length>0, title:document.title, len:(el.innerText||'').length, n:lines.length, lines};
  })()`;
  const r = await send(ws, 'Runtime.evaluate', { expression: expr, returnByValue: true });
  return r.result && r.result.value ? r.result.value : { ok: false, reason: 'no evaluate result' };
}

(async () => {
  if (!CHROME) { console.error('未找到 Chrome，请用 --chrome 指定路径'); process.exit(1); }
  if (!PROFILE || !fs.existsSync(PROFILE)) { console.error('必须用 --profile 指定含 cf_clearance 的 Chrome profile 目录'); process.exit(1); }
  fs.mkdirSync(OUTDIR, { recursive: true });
  const failFile = path.join(OUTDIR, 'failures.txt');
  fs.writeFileSync(failFile, '');

  const chrome = spawn(CHROME, [
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${PROFILE}`,
    '--no-first-run', '--no-default-browser-check',
    '--disable-blink-features=AutomationControlled',
    'about:blank',
  ], { stdio: 'ignore' });
  let ws;
  try {
    let targets;
    for (let i = 0; i < 40; i++) {
      try { targets = await getJson(`http://127.0.0.1:${PORT}/json`); if (targets.length) break; } catch (e) {}
      await sleep(500);
    }
    if (!targets || !targets.length) throw new Error('Chrome CDP 未就绪');
    const page = targets.find(t => t.type === 'page');
    ws = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise((res, rej) => { ws.on('open', res); ws.on('error', rej); });
    ws.on('message', raw => {
      const m = JSON.parse(raw);
      if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); }
    });
    await send(ws, 'Runtime.enable');
    await send(ws, 'Page.enable');

    // 先验证 cookie 是否有效（用第一页探测）
    console.log('COOKIE_CHECK', `${BASE}${START}.html`);
    await send(ws, 'Page.navigate', { url: `${BASE}${START}.html` });
    let valid = false;
    for (let w = 0; w < 20; w++) {
      await sleep(500);
      const r = await extractPage(ws).catch(() => null);
      if (r && r.ok && !CHALLENGE_RE.test(r.title)) { valid = true; break; }
      if (r && CHALLENGE_RE.test(r.title)) { console.error('检测到 Cloudflare 挑战页：cf_clearance 可能已过期。请用该 profile headful 打开站点完成一次验证后重试。'); process.exit(2); }
    }
    if (!valid) { console.error('无法读取正文：可能是 cookie 过期或容器选择器不匹配（当前 ' + SELECTOR + '）'); process.exit(2); }
    console.log('COOKIE_OK');

    let ok = 0, fail = 0, skip = 0;
    for (let n = START; n <= END; n++) {
      const outFile = path.join(OUTDIR, `page-${String(n).padStart(3, '0')}.txt`);
      if (fs.existsSync(outFile) && fs.statSync(outFile).size > 200) { skip++; continue; }
      let body = null, lastErr = '';
      for (let attempt = 1; attempt <= RETRY; attempt++) {
        try {
          await send(ws, 'Page.navigate', { url: `${BASE}${n}.html` });
          for (let w = 0; w < 25; w++) {
            await sleep(400);
            const r = await extractPage(ws).catch(() => null);
            if (r && r.ok) {
              const title = r.title || '';
              if (new RegExp('第' + n + '页').test(title)) { body = r; break; }
              if (CHALLENGE_RE.test(title)) { lastErr = 'cloudflare challenge'; break; }
            }
          }
          if (body) break;
        } catch (e) { lastErr = e.message; }
        await sleep(800);
      }
      if (body && body.n > 0) {
        fs.writeFileSync(outFile, body.lines.join('\n'), 'utf8');
        ok++;
        if (n % 10 === 0 || n === START) console.log(`[${n}/${END}] OK len=${body.len} n=${body.n}`);
      } else {
        fail++;
        console.log(`[${n}/${END}] FAIL ${lastErr || 'no body'}`);
        fs.appendFileSync(failFile, `${n}\t${BASE}${n}.html\t${lastErr}\n`);
      }
    }
    console.log(`DONE ok=${ok} fail=${fail} skip=${skip} outdir=${OUTDIR}`);
  } finally {
    if (ws) try { ws.close(); } catch (e) {}
    try { chrome.kill('force'); } catch (e) {}
  }
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
