#!/usr/bin/env node
/**
 * 沱书分页正文清洗拼接器。默认 dry-run，仅加 --apply 才覆盖目标文件（并自动备份 .bak）。
 *
 * 用法:
 *   node tuo_assemble.js --indir <页目录> --first 2 --last 409 \
 *     --title 在艰苦岁月里当阿姐 --author 九紫 --share "水印行" \
 *     --out <目标>.txt --apply
 *
 * 参数:
 *   --indir   页面目录（默认 ./tuo_pages）
 *   --first   起始页码（默认 2，跳过简介页）
 *   --last    结束页码（默认自动探测目录中的最大页码）
 *   --title   书名（必填）
 *   --author  作者（必填）
 *   --share   头尾水印行（可选；留空则不写入水印）
 *   --out     输出 TXT 路径（必填）
 *   --apply   实际写入；否则只打印统计
 *   --start-head 正文起始标记（默认 '第1章' 的正则 ^第\s*1\s*章$）
 *   --chapter-re 章节标题正则（默认 ^第\s*(\d+)\s*章）
 *   --keep-wm  保留站点行内水印（默认删除）
 *   --backup   覆盖前备份后缀（默认 .bak）
 */
const fs = require('fs');
const path = require('path');

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  if (i >= 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--')) return process.argv[i + 1];
  const eq = process.argv.find(a => a.startsWith('--' + name + '='));
  return eq ? eq.slice(name.length + 3) : def;
}
const APPLY = process.argv.includes('--apply');
const KEEP_WM = process.argv.includes('--keep-wm');
const INDIR = path.resolve(arg('indir', 'tuo_pages'));
const FIRST = parseInt(arg('first', '2'), 10);
const TITLE = arg('title', '');
const AUTHOR = arg('author', '');
const SHARE = arg('share', '');
const OUT = path.resolve(arg('out', ''));
const SUFFIX = arg('backup', '.bak');
const START_HEAD_RE = new RegExp(arg('start-head', '^第\\s*1\\s*章$'));
const CHAPTER_RE = new RegExp(arg('chapter-re', '^第\\s*(\\d+)\\s*章'));
const WATERMARK = `${TITLE}_${AUTHOR}`;

function detectLast() {
  const nums = fs.readdirSync(INDIR).map(f => /^page-(\d+)\.txt$/.exec(f)).filter(Boolean).map(m => parseInt(m[1], 10));
  return nums.length ? Math.max(...nums) : 0;
}
const LAST = parseInt(arg('last', String(detectLast())), 10);

if (!TITLE || !AUTHOR) { console.error('必须提供 --title 和 --author'); process.exit(1); }
if (!OUT) { console.error('必须提供 --out'); process.exit(1); }

let allLines = [];
const missingFiles = [];
for (let n = FIRST; n <= LAST; n++) {
  const fp = path.join(INDIR, `page-${String(n).padStart(3, '0')}.txt`);
  if (!fs.existsSync(fp)) { missingFiles.push(n); continue; }
  const lines = fs.readFileSync(fp, 'utf8').split('\n').map(x => x.trim()).filter(Boolean);
  allLines = allLines.concat(lines);
}
if (missingFiles.length) console.log('MISSING_PAGES', JSON.stringify(missingFiles));

const start = allLines.findIndex(l => START_HEAD_RE.test(l));
if (start < 0) throw new Error('未找到正文起点（--start-head 正则未匹配），请检查 --first 或自定义 --start-head');
allLines = allLines.slice(start);

let wmRemoved = 0, dropRemoved = 0;
const cleaned = [];
for (const l of allLines) {
  if (!KEEP_WM && l === WATERMARK) { wmRemoved++; continue; }
  if (/^主角视角陆红莲谢磐石$/.test(l) || /^征文活动优秀作品奖章$/.test(l)) { dropRemoved++; continue; }
  cleaned.push(l);
}

const chNums = [];
for (const l of cleaned) { const m = l.match(CHAPTER_RE); if (m) chNums.push(parseInt(m[1], 10)); }
const maxCh = chNums.length ? Math.max(...chNums) : 0;
const missing = [], dup = [];
for (let i = 1; i <= maxCh; i++) {
  const c = chNums.filter(n => n === i).length;
  if (c === 0) missing.push(i);
  else if (c > 1) dup.push(i + ':' + c);
}

const body = cleaned.join('\n\n');
const head = `《${TITLE}》  作者：${AUTHOR}\n` + (SHARE ? `${SHARE}\n` : '') + (maxCh ? `共 ${maxCh} 章\n\n` : '\n');
const out = head + body + (SHARE ? `\n\n\n${SHARE}\n` : '\n');

console.log('PAGES', `${FIRST}..${LAST}`);
console.log('BODY_START_LINE', start, 'WM_REMOVED', wmRemoved, 'DROP_REMOVED', dropRemoved);
console.log('BODY_LINES', cleaned.length);
console.log('CHAPTER_HEADS', chNums.length, 'MAX_CH', maxCh);
console.log('MISSING_CHAPTERS', JSON.stringify(missing), 'DUP_CHAPTERS', JSON.stringify(dup));
console.log('OUTPUT_CHARS', out.length, 'BYTES', Buffer.byteLength(out, 'utf8'));
console.log('FIRST_LINES', JSON.stringify(cleaned.slice(0, 3)));
console.log('LAST_LINES', JSON.stringify(cleaned.slice(-3)));

if (APPLY) {
  if (fs.existsSync(OUT)) { fs.copyFileSync(OUT, OUT + SUFFIX); console.log('BACKUP', OUT + SUFFIX); }
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, out, 'utf8');
  console.log('APPLIED ->', OUT);
} else {
  console.log('DRY_RUN (加 --apply 才写入)');
}
